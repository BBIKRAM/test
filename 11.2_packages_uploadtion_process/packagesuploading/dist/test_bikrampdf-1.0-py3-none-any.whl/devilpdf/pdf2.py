def what():
    print("this is another test")